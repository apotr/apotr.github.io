// Anna Sokolinskaya

#ifndef ACTIONEXCEPTION_H_
#define ACTIONEXCEPTION_H_

#include <exception>
#include <string>

const std::string NO_PARTICIPANT_MSG = "Action descriptor should have at least one participant: ";
const std::string NO_SUCH_ACTION_MSG = "No action with this name exists: ";
const std::string NO_SUCH_CLASS_MSG = "No class with this name exists: ";
const std::string NO_OBJECTS_MSG = "No actual participants provided: ";
const std::string NO_SUCH_OBJECT_MSG = "No object with this name exists: ";
const std::string NO_PARTICIPANT_MATCH_MSG = "Number of actual participant doesn't match definition: "; 
const std::string NO_INNER_MATCH_MSG = "Number of inner function participants and/or parameters doesn't match definition: "; 
const std::string EMPTY_NODE = "Tag contents are empty";
const std::string NO_OBJECT_INIT = "One of the objects doesn't have initial value: ";
const std::string NO_OBJECT_INFO_MSG = "Name and class should be provided for each object";
const std::string NO_OBJ_INNER = "Objects for inner duplication not specified in action descriptor: ";
const std::string CLASS_ERROR_MSG = "Name and type should be provided for each class";
const std::string NO_FIELD_MSG = "Initial values should be provided for particular fields: ";
const std::string TIMINGS_COMMON = "Either rate and relative deadline or common guard should be provided: ";
const std::string NO_PARAMETER_MATCH_MSG = "Number of actual paramaters doesn't match definition: ";

class ActionException : public std::exception
{
public:

	ActionException(std::string text);		//parameter contains description of the error
	ActionException(const ActionException &obj);		//copy constructor

	virtual ~ActionException() throw();

	std::string info();	//returns error message

private:

	std::string message;	//description of the error

};

#endif /* ACTIONEXCEPTION_H_ */
