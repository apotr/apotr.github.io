// Copyright Hannu-Matti J�rvinen 2012

#ifndef ACTIONRUN_H
#define ACTIONRUN_H

// If READING is true, tries to emulate interrupts when reading
// Introduces two functions: wait_read to be used as a local guard
// and reading to be used by the body
//#define READING

// Fake bool type
typedef int bool;
#define true 1
#define false 0

// Types to be easily changed
typedef unsigned int uint;
typedef unsigned int Mask;

// Number of action participants
#define MAX_PARTICIPANTS (sizeof(Mask)*8-1)


// Object, action, and pointers to them

struct Class_definition;
typedef struct Class_definition* Class_descriptor;
struct Object;
typedef struct Object *volatile Objectpointer;
struct Action_definition;
typedef struct Action_definition* Action_descriptor;
struct Action;
typedef struct Action* Actionpointer;

typedef struct Timings_type {
  uint rate;
  uint relative_deadline;
  uint local_timeouts[MAX_PARTICIPANTS];
  uint local_deadlines[MAX_PARTICIPANTS];
  bool one_shot[MAX_PARTICIPANTS];
} Timings_type;

// Function types

typedef void (*Actionfunction)(uint parameters[],  // Action parameters
			       Objectpointer p[],  // Action participants
			       Mask *unchanged,  // If any of the participants has been updated
			       Mask *deleted,    // If any of the participants has been deleted
			       Actionpointer runner);    // myself

typedef void (*application) ();  // Initializing function
typedef bool (*Guardfunction)(uint parameters[], Objectpointer p[]);  // Common guard
typedef bool (*Localfunction)(Objectpointer p);    // Local guard
typedef Timings_type (*Timings) (uint parameters[]);	// How to compute timings

typedef void (*Initial_object)(void *);   // Initializes an object
typedef void (*Destructor)(void **);     // Destructor of an object
typedef void (*Copy)(void *old, void *new);           // Copies an object

// Visible functions

// Runner
// Starts and stops the whole thing
// threads gives the number of executing threads
// application is a function that initializes the application

int runner (uint threads, application application_init);


// Create object
// Creates an object. Callable from application init

Class_descriptor create_class(char *name,
			      uint size,
			      Initial_object initially,
			      Copy copy,
			      Destructor destroy);

Objectpointer create_object (Class_descriptor);

// Creates action descriptor

Action_descriptor create_action_descriptor (char *name,
					    Actionfunction body,
					    Guardfunction common_guard,
					    Timings timing,
					    Mask read_only,
					    uint parameter_count,
					    uint participant_count,
					    ...);
// Create action
// Creates an action. Callable from application init (runner == NULL)
// or an action (runner == calling action)

Actionpointer create_action(Actionpointer runner,
			    Action_descriptor descriptor,
			    ...);

uint action_id(Actionpointer ap);

// Duplicate objects
// Duplicate objects duplicates a set of objects.
// Callable from an action

void delete_action(Actionpointer runner);

void duplicate_objects(Actionpointer runner, Objectpointer new_objects[], uint count, ...);

void *object_data(Objectpointer object);
uint object_id(Objectpointer object);

#ifdef READING

// This a circular queue for reading
Objectpointer reading_object;

// This is function to be called as a local guard
// when checking if there are enough characters read
// to enable this action
bool wait_read(Objectpointer read_object, uint number);

// This is a procedure to be called to do actual
// reading
// Returns the actual numbers of chars read
int read_chars(Objectpointer read_object, uint number, char localbuffer[]);

#endif

// Action timing
void action_timeout_absolute(Actionpointer action, uint absolute_time);
void action_timeout_relative(Actionpointer action, uint relative_time);

// Debug definitions

#ifdef EBUG

extern Actionpointer action_list[];
extern volatile uint action_count;

#define Debug printf
#define Return(x, y) printf("Vahdin %s paluuarvo %d\n", (y), (x)); return x

#ifndef CHECK
#define CHECK
#endif
#ifndef STATISTICS
#define STATISTICS
#endif

#else

#define Debug //
#define Return(x, y) return x

#endif

#endif
