// Anna Sokolinskaya
#include <iostream>
#include "actionparser.hpp"

int main(int argc, char* argv[])
{
	if (argc != 3) {
		std:: cout << "Error: input and output files not provided";
		return -1;
	}
	
	ActionParser* parser = new ActionParser();
	parser->parseFile(argv[1], argv[2]);
		
	delete parser;
	return 0;
}
