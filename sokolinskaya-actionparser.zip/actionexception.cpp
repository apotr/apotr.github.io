// Anna Sokolinskaya

#include <string>
#include <exception>
#include "actionexception.hpp"

using std::string;

//parameter contains description of the error
ActionException::ActionException(string text) : std::exception() {
	message = text;
}

ActionException::ActionException(const ActionException &obj) : std::exception(obj)	//copy constructor
{
	message = obj.message;
}


ActionException::~ActionException() throw()
{
}

string ActionException::info()	//returns error message
{
	string text = "Error: ";
	text+= message;
	return text;
}
