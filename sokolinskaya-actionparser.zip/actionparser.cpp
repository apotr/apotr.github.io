// Anna Sokolinskaya
#include <iostream>
#include <string>
#include <sstream>
#include "actionparser.hpp"

using namespace rapidxml;
using std::cout;
using std::endl;
using std::string;
using std::vector;

#define SECONDS 1

ActionParser::ActionParser() {
	objectCounter = 0;
}

// public funtion parsing XML file with a program
void ActionParser::parseFile(const char* inFilename, const char* outFilename) {
	
	try {

		outputFile.open (outFilename);
		inputFile = new file<>(inFilename);
		doc = new xml_document<>;
		doc->parse<0>(inputFile->data());
		
		outputFile << "#include \"actionrun.h\"\n#include <stdio.h>\n#include <stdlib.h>\n#include <time.h>\n\n";

		cout << "Parsing began" << endl;
		xml_node<>* rootNode = doc->first_node("program");

		xml_node<>* nextNode = rootNode->first_node("threads");
		if (nextNode) {
			threadsNumber = stringToNumber(getText(nextNode));	
		}
		else {
			threadsNumber = 0;
		}
		
		nextNode = rootNode->first_node("types");
		if (nextNode) {
			parseTypes(nextNode);
		}
		nextNode = rootNode->first_node("class_descriptors");
		if (nextNode) {
			parseClasses(nextNode);
		}	
		nextNode = rootNode->first_node("action_descriptors");
		if (nextNode) {
			parseActDesc(nextNode);
		}
		
		outputFile << "void application_body()\n{" << endl;
		createClasses();
		createActionDes();
	
		nextNode = rootNode->first_node("initialization");
		if (nextNode) {
			parseInit(nextNode);
		}
		
		outputFile << "};\n";
		outputFile << "// application body" << endl <<
			"int main()\n{\n";
		if (threadsNumber > 0) {
			outputFile << "return runner (" << threadsNumber << ", application_body);\n}\n";
		}	
		else {
			// if number of thereads not given, request it
			outputFile << "printf(\"Number of executors? \");\nint exe;\n" <<
				"scanf(\"%d\", &exe);\nif (exe <= 0 || exe > 10)\nexe = 1;\n" <<
				"return runner(exe, application_body);\n}\n";
		}		
		outputFile.close();
		cout << "Parsing ended" << endl;
	}
	catch (ActionException ex) {
		cout << ex.info() << endl;
    	return;
    }
}

ActionParser::~ActionParser() {

}

// parse element types
void ActionParser::parseTypes(xml_node<>*first) {

	outputFile << "//types" << endl;
	outputFile << getText(first) << endl;

}

// parse element class_descriptors
void ActionParser::parseClasses(xml_node<>*first) {

	outputFile << "//classes" << endl;
	xml_node<> * firstClass = first->first_node();
	
	if (!firstClass) {
		return;
	}
	
	// parse each of the classes
	for (xml_node<> * node = firstClass; node; node = node->next_sibling())
	{
		xml_node<> * property = node->first_node("name");
		if (!property) {
			throw (ActionException(CLASS_ERROR_MSG ));
		}
		string className = getText(property);
		
		ClassInfo newClassInfo;
		newClassInfo.deleteFunction = false;
		newClassInfo.copyFunction = false;
		newClassInfo.initFunction = false;
	
		property = node->first_node("classtype");
		if (!property) {
			throw (ActionException(CLASS_ERROR_MSG ));
		}
		string classType = getText(property);
		if (node->first_node("init")) {
			outputInitFunction(node, newClassInfo);
		}
		
		if (node->first_node("copy")) {
			outputCopyFunction(node, newClassInfo);
		}
		
		if (node->first_node("delete")) {
			outputDeleteFunction(node, newClassInfo);
		}
		
		newClassInfo.classNode = node;
		// save class info into the map
		classMap.insert(ClassMap::value_type(className, newClassInfo));
	}
}

// output initialization function for a class
void ActionParser::outputInitFunction(xml_node<>*node, ClassInfo& info) {

	string name = getText(node->first_node("name"));
	string type = getText(node->first_node("classtype"));
	
	info.initFunction = true;
	outputFile << "void init_" << name << "(void *newobj)\n{\n" <<
		type << "*newRealObj" << " = (" << type << "*) newobj;\n";

	xml_node<> * firstField = node->first_node("init")->first_node("field");
	if 	(!firstField) {
			outputFile << "*newRealObj = " << 
			getText(node->first_node("init")) << ";\n";	
	} else {
		for (xml_node<> * field = firstField; field; field = field->next_sibling()) {
		
		if (!field->first_node("name") || !field->first_node("value")) {
			throw (ActionException(NO_FIELD_MSG + name));
		}	
		outputFile << "newRealObj->" << getText(field->first_node("name")) <<
			" = " << getText(field->first_node("value")) << ";\n";
		}
	}
	outputFile << "}\n";
}

 // output copy function for a class
void ActionParser::outputCopyFunction(rapidxml::xml_node<>*node, ClassInfo& info) {

	string oldName, newName;
	string name = getText(node->first_node("name"));
	string type = getText(node->first_node("classtype"));
	
	xml_node<> * property = node->first_node("copy")->first_node("old_name");
	if (property) {
		oldName = getText(node->first_node("copy")->first_node("old_name"));
	}
	else {
		oldName = "old_" + name;
	}	
	property = node->first_node("copy")->first_node("new_name");
	if (property) {
		newName = getText(node->first_node("copy")->first_node("new_name"));
	}
	else {
		newName = "new_" + name;
	}
	
	if (node->first_node("copy")->first_node("code")) {
		info.copyFunction = true;
		outputFile << "#define " << oldName << " (*_tempPointer_old)\n" <<
			"#define " << newName << " (*_tempPointer_new)\n" <<
			"void copy_" << name << "(void *oldobj, void *newobj) {\n" << 
			type << "* _tempPointer_old = (" << type << "*) oldobj;\n" <<
			type << "* _tempPointer_new = (" << type << "*) newobj;\n" <<
			getText(node->first_node("copy")->first_node("code")) <<
			"}\n" << "#undef " << oldName << endl <<
			"#undef " << newName << endl << endl;
	}
}	

// output delete function for a class
void ActionParser::outputDeleteFunction(rapidxml::xml_node<>*node, ClassInfo& info) {
	if (node->first_node("delete")->first_node("code")) {
		info.deleteFunction = true;
		outputFile << "void delete_" << getText(node->first_node("name"))<<
			"(void **) {\n" <<
			getText(node->first_node("delete")->first_node("code")) <<
			"\n}\n";
	}
}

// parse element action_descriptors
void ActionParser::parseActDesc(xml_node<>*first) {

	outputFile << "//action_descriptors" << endl;
	if (!first->first_node())
		return;
	xml_node<> * firstAction = first->first_node();
	int desc_count = 1;
	
	// count action dascriptors
	for (xml_node<> * action = firstAction; action; action = action->next_sibling()){
		desc_count++;
	}
	
	outputFile << "static Action_descriptor actionDescriptors[" << desc_count << "];\n";
	
	int index = 0;
	// for each action descriptor
	for (xml_node<> * action = firstAction; action; action = action->next_sibling())
	{
		string actName = getText(action->first_node("name"));
		ActDescInfo actInfo;
		actInfo.actionNode = action;
		actInfo.index = index;
		actInfo.commonGiven = 0;	
		actInfo.partCount = 0;
		if (action->first_node("cguard")) {
			string commonValue = getText(action->first_node("cguard"));
			if (commonValue != "true" && commonValue != "True" && commonValue != "TRUE")
				actInfo.commonGiven = 1;
		}

		// get individual parameter names
		xml_node<> * parameters = action->first_node("parameters");
		if (parameters) {
			splitString(getText(parameters), actInfo.paramVector, " ,");
		}

		string paramDefines = "";
		string paramUndefs = "";
		
		// define parameter names for the action body and guard 
		for(vector<string>::size_type i = 0; i != actInfo.paramVector.size(); i++) {
			paramDefines = paramDefines + "#define " + actInfo.paramVector[i] + " parameters[" + numberToString(i) + "]\n";
			paramUndefs = paramUndefs + "#undef " + actInfo.paramVector[i] + "\n";
		}
		
		// find first participant
		xml_node<> * firstPart = action->first_node("participant");
		if (!firstPart) {
			throw (ActionException(NO_PARTICIPANT_MSG + actName));
		}
		
		// generate strings containing common guard, body and timing function 
		string common = "bool guard_" + actName + "_common(uint *parameters, Objectpointer objects[])\n{\n";
		string body = "void body_" + actName + "(uint *parameters, Objectpointer *objects, Mask *unchanged, Mask *deleted, Actionpointer runner)\n{\n";
		string timings = "Timings_type timings_" + actName + "(uint *param)\n{\nTimings_type tim = {0};\n";
		string bodyDefines = "";
		string bodyUndefs = "";
		
		// check for timing settings
		if (action->first_node("rate")) {
			if (actInfo.commonGiven) {
				throw (ActionException(TIMINGS_COMMON + actName));
			}
			string rate = getText(action->first_node("rate"));
			timings += "tim.rate = " + rate + ";\n";
		}
		if (action->first_node("relative_deadline")) {
			if (actInfo.commonGiven) {
				throw (ActionException(TIMINGS_COMMON + actName));
			}
			string relative = getText(action->first_node("relative_deadline")); 
			timings += "tim.relative_deadline = " + relative + ";\n";
		}
		
		// create local guards for each participant, common guard and a body
		int i = 0; // participant index
		for (xml_node<> * curPart = firstPart; curPart; curPart = curPart->next_sibling("participant")) {
		
			string partName = getText(curPart->first_node("name"));
			string partClass = getText(curPart->first_node("class"));
							
			ItClass itClass = classMap.find(partClass);
			if (itClass == classMap.end()) {
				throw (ActionException(NO_SUCH_CLASS_MSG + partClass));
			}
			string partType = getText(itClass->second.classNode->first_node("classtype"));

			// output local guard
			if (curPart->first_node("lguard")) {
				outputFile << "bool guard_" << actName << "_local_" << partName << 
					"(Objectpointer object)" << endl << '{' << endl <<
					partType << " *x = (" << partType << "*)" << "object_data(object);" << endl <<
					partType << " " << partName << " = (*x);" << endl <<
					"bool result = " << getText(curPart->first_node("lguard")) << ";" << endl << "Return(result, " <<
					"\"local " << actName << " guard " << partName << "\");\n}\n\n";
			}
			
			string partInfo = partType + "* " + partName + "Pointer" + " = (" + partType + "*) object_data(objects[" + numberToString(i) + "]);\n";
			string partDefine = "#define " + partName + " (*" + partName + "Pointer)\n";
			string partUndef = "#undef " + partName + "\n";
			common = common + partInfo;
			body = body + partInfo;
			bodyDefines = bodyDefines + partDefine;
			bodyUndefs = bodyUndefs + partUndef;
			
			// check for timing settings of the participant
			if (curPart->first_node("local_timeout")) {
				string l_timeout = getText(curPart->first_node("local_timeout"));
				timings = timings + "tim.local_timeouts[" + numberToString(i) + "] = " + l_timeout + ";\n";
			}
			if (curPart->first_node("local_deadline")) {
				string l_deadline = getText(curPart->first_node("local_deadline"));
				timings = timings + "tim.local_deadlines[" + numberToString(i) + "] = " + l_deadline + ";\n";
			}
			if (curPart->first_node("one_shot")) {
				string o_shot = getText(curPart->first_node("one_shot"));
				timings = timings + "tim.one_shot[" + numberToString(i) + "] = " + o_shot + ";\n";
			}
			
			i++;
		}
		actInfo.partCount = i;
		actMap.insert(ActDescMap::value_type(actName, actInfo));

		// deal with body
		string bodyCode = getText(action->first_node("body"));
		std::size_t found = bodyCode.find("CREATEACTION");
		string first;
		string innerBody;
		string third;
		
		// check for CREATEACTION macro calls
		while (found != std::string::npos)
		{
			// create inner actions
			vector<string> params;
			std::size_t firstPos = found + 12;
			std::size_t lastPos = bodyCode.find(";", found);
			splitString(bodyCode.substr(firstPos, lastPos-firstPos), params, " ,()");
			if (params.size() < 2) {
				throw (ActionException(NO_INNER_MATCH_MSG + actName));
			}
			
			first = bodyCode.substr(0,found);
			innerBody = "create_action(runner, ";
			third = bodyCode.substr(lastPos+1, string::npos);
		
			string innerName = params[0];
			
			ItAct itInner = actMap.find(innerName);
			if (itInner == actMap.end()) {
				throw (ActionException(NO_SUCH_ACTION_MSG + innerName));
			}
			
			if ((itInner->second.paramVector.size() + itInner->second.partCount) != params.size()-1) {
				throw (ActionException(NO_INNER_MATCH_MSG + innerName));
			}
			
			innerBody = innerBody + "actionDescriptors[" + numberToString(itInner->second.index) + "]";

			for (vector<string>::iterator it = params.begin()+1; it!=params.end(); it++) {
				
				int partNumber = -1;
				bool found = 0;
				xml_node<> * firstPart = action->first_node("participant");
				for (xml_node<> * curPart = firstPart; curPart&&(!found); curPart = curPart->next_sibling("participant")) {
					partNumber++;
					if ((*it).compare(getText(curPart->first_node("name"))) == 0) {
						innerBody += ", objects[";
						innerBody += numberToString(partNumber);
						innerBody += "]";
						found = 1;
					}
				}
				if (!found) {
					innerBody += ", ";
					innerBody += *it;
				}
			}
			innerBody += ");\n";

			bodyCode = first + innerBody + third;
			
			found = bodyCode.find("CREATEACTION",found+1);
		}
		
		// check for DELETEACTION macro calls
		found = bodyCode.find("DELETEACTION");
		while (found != std::string::npos)
		{
			std::size_t lastPos = bodyCode.find(";", found);
			first = bodyCode.substr(0,found);
			innerBody = "delete_action(runner);";
			third = bodyCode.substr(lastPos+1, string::npos);
			bodyCode = first + innerBody + third;
			found = bodyCode.find("DELETEACTION",found+1);
		}
		
		// check for DUPLICATE macro calls
		found = bodyCode.find("DUPLICATE");
		while (found != std::string::npos)
		{
			vector<string> params;
			std::size_t firstPos = found + 10;
			std::size_t lastPos = bodyCode.find(";", found);
			splitString(bodyCode.substr(firstPos, lastPos-firstPos), params, " ,");
			if (params.size() == 0) {
				throw (ActionException(NO_OBJ_INNER + actName));
			}

			first = bodyCode.substr(0,found);
			innerBody = "duplicate_objects(runner";
			third = bodyCode.substr(lastPos, string::npos);
			for (vector<string>::iterator it = params.begin(); it!=params.end(); it++) {
				innerBody += ", ";
				innerBody += *it;
			}
			
			//innerBody += "\n";
			bodyCode = first + innerBody + third;
			found = bodyCode.find("DUPLICATE",found+1);
		}
	
		// output timings function
		outputFile << timings << "return tim;\n}\n\n";
		outputFile << bodyDefines << paramDefines;
		
		// output common guard and body
		if (actInfo.commonGiven) {
			outputFile << common <<  "bool result = " << 
				getText(action->first_node("cguard")) << ";\n" << 
				"Return(result, " << "\"common " << actName << " guard\");\n}\n\n";
		}
		
		outputFile << body << "*unchanged = 0; *deleted = 0;" << endl << bodyCode << endl <<
			'}' << endl << paramUndefs << bodyUndefs << endl << endl;
		index++;
	}
}

// parse initialization element
void ActionParser::parseInit(xml_node<>*first) {

	try {

		xml_node<> * objects = first->first_node("objects");
		if (objects) {
			xml_node<> * firstObject = objects->first_node();
		
			for (xml_node<> * curObject = firstObject; curObject; curObject = curObject->next_sibling())
			{
				parseObject(curObject); // parse each object
			}
		}

		parseActionInstances(first->first_node("actions")); // parse actions
		createInstances(); // output functions creating objects and actions
	}
	catch(ActionException ex) {
		throw(ex);
	}
}

// parse an object element
void ActionParser::parseObject(xml_node<>*object) {

	if (!object->first_node("names") || !object->first_node("class")) {
		throw (ActionException(NO_OBJECT_INFO_MSG));
	}
	
	string names = getText(object->first_node("names"));
	string type =  getText(object->first_node("class"));
	string inits;
	
	ItClass itClass = classMap.find(type);
	if (itClass == classMap.end()) {
			throw (ActionException(NO_SUCH_CLASS_MSG + type));
	}

	bool hasInit = false;
	if (object->first_node("initvalues")) {
			hasInit = true;
		}
	
	vector<string> objVector;
	vector<string> initVector;
	splitString(names, objVector, " ,");
	
	if (hasInit) {
		splitString(getText(object->first_node("initvalues")), initVector, " \n\r\t");
	}
		
	string objName;
	string initValue;
	unsigned int numInit = 0;
	
	// parse each individual object 
	for (vector<string>::iterator itObj = objVector.begin(); itObj != objVector.end(); ++itObj) {
		
		objName = *itObj;
		ObjectInfo objInfo;
		
		if (hasInit) {
			if (initVector.size() <= numInit) {
				throw(ActionException(NO_OBJECT_INIT + objName));
			}
			initValue = initVector[numInit];
			if (initValue[initValue.size()-1]==',')
				initValue.erase(initValue.size()-1);
			numInit++;
		}
		else {
			initValue = "";
		}
				
		objInfo.classNode = itClass->second.classNode;
		objInfo.rolesNumber = 0;
		objInfo.init = initValue;
		objMap.insert(ObjectMap::value_type(objName, objInfo));
	}
}
	
// parse actions element
void ActionParser::parseActionInstances(xml_node<>*header) {
	
	if (!header) {
		return;
	}
	
	// for each action
	for (xml_node<> * curAction = header->first_node() ; curAction; curAction = curAction->next_sibling()) {
		
		string actName = getText(curAction->first_node("name"));
		ItAct itAct = actMap.find(actName);
		if (itAct == actMap.end()) {
			throw (ActionException(NO_SUCH_ACTION_MSG + actName));
		}
		
		InstanceInfo info;
		info.actDescInfo = &itAct->second;	

		// process objects
		xml_node<> * objNames = curAction->first_node("with"); 
		if (!objNames) {
			throw (ActionException(NO_OBJECTS_MSG + actName));
		}
		
		vector<string> namesVector;
		splitString(getText(objNames), namesVector, " ,");
		string objName;
		
		// parse actual values of participating objects
		for (vector<string>::iterator itName = namesVector.begin(); itName != namesVector.end(); ++itName) {

			objName = *itName;
			ItObj itObj = objMap.find(objName);
			
			if (itObj == objMap.end()) {
				throw (ActionException(NO_SUCH_OBJECT_MSG + objName));
			}
			itObj->second.rolesNumber ++;
			info.objects.push_back(objName);
		}
		
		xml_node<> * parameters = curAction->first_node("parameters");
		if (parameters) {
			splitString(getText(parameters), info.parameters, " ,");
		}

		instanceVector.push_back(info);
	}
}

 // output creation of class descriptors
void ActionParser::createClasses() {

	outputFile << "//classes" << endl;
	// for each class
	for(ItClass itClass = classMap.begin(); itClass != classMap.end(); itClass++) {
		
		string name = itClass->first;
		string initStr, copyStr, deleteStr;
		initStr = copyStr = deleteStr = "NULL";
		if (itClass->second.initFunction)
			initStr = "init_" + name;
		if (itClass->second.copyFunction)
			copyStr = "copy_" + name;
		if (itClass->second.deleteFunction)
			deleteStr = "delete" + name;
			
		outputFile << "Class_descriptor class_" << name << " = create_class(\""
			<< name << "\", sizeof(" << getText(itClass->second.classNode->first_node("classtype")) << "), " <<
			initStr << ", " << copyStr << ", " << deleteStr << ");\n";
	}
}

// output creation of action descriptors
void ActionParser::createActionDes() {
	
	outputFile << "//action descriptors" << endl;

	// for each action descriptor
	for(ItAct itAct = actMap.begin(); itAct != actMap.end(); itAct++) {
		
		string name = itAct->first;
		outputFile << "actionDescriptors[ " << numberToString(itAct->second.index) << "] = " <<
			"create_action_descriptor (\"" << name <<
			"\", body_" << name << ", ";
		if (itAct->second.commonGiven) {
			outputFile <<  "guard_" << name << "_common, ";
		}
		else {
			outputFile << "NULL, ";
		}
		outputFile << "timings_" << name << ", ";
		outputFile << "0, ";
		outputFile << itAct->second.paramVector.size() << ", ";
		string partGuards = "";
		
		xml_node<> * firstPart = itAct->second.actionNode->first_node("participant");
		for (xml_node<> * curPart = firstPart; curPart; curPart = curPart->next_sibling("participant")) {
			
			string partName = getText(curPart->first_node("name"));
			if (curPart->first_node("lguard")) {
				partGuards += ", guard_" + name + "_local_" + partName;
			} else {
				partGuards += ", NULL";
			}
		}
		outputFile << itAct->second.partCount;
		outputFile << partGuards << ");\n";
		
	}
}

// output creation of objects and actions
void ActionParser::createInstances() {

	outputFile << "Debug (\"Making objects\\n\");" << endl << endl <<
			"//initialization" << endl;
	outputFile << "//objects" << endl;
	
	// for each individual object
	for(ItObj itObj = objMap.begin(); itObj != objMap.end(); itObj++) {
		string objName = itObj->first;
		string className = getText(itObj->second.classNode->first_node("name"));
		string type = getText(itObj->second.classNode->first_node("classtype"));
		string init = itObj->second.init;
		
		outputFile <<  "Objectpointer _obj_" << objName << "  = create_object(class_" <<
			className << ");" << endl;
		if (init !="") 
		{
			outputFile << type << "* " << objName << " = (" << type << 
				"*) object_data(_obj_" << objName << ");" << endl;
			outputFile << type << " temp" << objName << " = " << init << ";\n" << 
				"(*" << objName << ") = temp" << objName << ";\n";
		}
	}
	
	outputFile << "//actions" << endl;
	
	// for each action
	for(ItInsnance itIns = instanceVector.begin(); itIns != instanceVector.end(); itIns++) {
		
		string actName = getText(itIns->actDescInfo->actionNode->first_node("name"));
	
		outputFile <<  "create_action(NULL, actionDescriptors[" << numberToString(itIns->actDescInfo->index) << ']';
		
		if (itIns->parameters.size() != itIns->actDescInfo->paramVector.size()) {
			throw(ActionException(NO_PARAMETER_MATCH_MSG + actName));
		}
		
		for(vector<string>::size_type i = 0; i != itIns->parameters.size(); i++) {
			outputFile << ", " << itIns->parameters[i]; 
		}
			
		// for each participant
		vector<string> *objectVector = &itIns->objects;
		
		if (objectVector->size() != itIns->actDescInfo->partCount) {
			throw(ActionException(NO_PARTICIPANT_MATCH_MSG + actName));
		}
		
		for(vector<string>::iterator it = objectVector->begin(); it != objectVector->end(); ++it) {
			outputFile << ", _obj_" << *it;
		}
		
		outputFile << ");" << endl;
		
	}

}

// get textual content of the node
string ActionParser::getText(rapidxml::xml_node<>*node) {

	if (!node->first_node()) {
		throw(ActionException(EMPTY_NODE));
	}
	
	// if text is inside CDATA, get it
	if (node->first_node()->type() == node_cdata) {
		return trim(node->first_node()->value());
	}
	else {
		return trim(node->value());
	}
}

// trim a string from left and right
string ActionParser::trim(const string& str)
{
    const std::size_t strBegin = str.find_first_not_of(" \r\t\n");
    if (strBegin == string::npos)
        return ""; // no content
    const std::size_t strEnd = str.find_last_not_of(" \r\t\n");
    const std::size_t strRange = strEnd - strBegin + 1;
    return str.substr(strBegin, strRange);
}

// split string into multuple strings
void ActionParser::splitString(const string& str, vector<string>& tokens, const string delimiters) {

	string::size_type pos, lastPos = 0;
	
	while(true)
	{
		pos = str.find_first_of(delimiters, lastPos);
		if(pos == string::npos)
		{
			pos = str.length();

			if(pos != lastPos)
				tokens.push_back(string(str.data()+lastPos,
					(unsigned int)pos-lastPos ));
			break;
		}
		else
		{
			if(pos != lastPos)
            tokens.push_back(string(str.data()+lastPos,
                  (unsigned int)pos-lastPos));
		}
		lastPos = pos + 1;
	}
}

// convert number to a string
string ActionParser::numberToString(int num)
{
	std::ostringstream ss;
    ss << num;
    return ss.str();
}

// convert srting to a number
int ActionParser::stringToNumber(const string& str)
{
     int res = 0;
     std::stringstream ss;
     ss << str;
     ss >> res;
     ss.str("");
     ss.clear();
     return res;
}