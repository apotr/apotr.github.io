
// Copyright Hannu-Matti J�rvinen 2012-2015
// Windows-specific parts by Matti Vuori 2014

#include "actionrun.h"
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <time.h>
#include <stdarg.h>
#include <strings.h>

//#define STRLCPY

#ifndef STRLCPY
size_t strlcpy(char *source, char *dest, size_t count)
{
  size_t number = 0;
  while(number < count-1 && (*dest++ = *source++)) {
    number++;
  }
  *dest = '\0';
  return number;
}
#endif

// The maximum length of the action and class names
#define NAME_LENGTH 16
// Log one
#define LOG_FILE "actionrun.log"

#ifdef LOG_FILE
FILE *log_file;

#define VERYLONG 300

#define LOG1(x) fprintf(log_file, (x)); fflush(log_file)
#define LOG2(x,y) fprintf(log_file, (x), (y)); fflush(log_file)
#define LOG3(x,y,z) fprintf(log_file, (x), (y), (z)); fflush(log_file)
#define LOG4(x,y,z,a) fprintf(log_file, (x), (y), (z), (a)); fflush(log_file)
#define LOG5(x,y,z,a,b) fprintf(log_file, (x), (y), (z), (a), (b)); fflush(log_file)
#define LOG6(x,y,z,a,b,c) fprintf(log_file, (x), (y), (z), (a), (b), (c)); fflush(log_file)
#else
#define LOG1(x)
#define LOG2(x,y)
#define LOG3(x,y,z)
#define LOG4(x,y,z,a)
#define LOG5(x,y,z,a,b)
#define LOG6(x,y,z,a,b,c)
#endif
// If the statistics of execution is displayed
#define STATISTICS

#ifdef STATISTICS
// Counts the number of mutex calls; only for statistics
#define COUNT_MUTEX
  volatile long int local_guard_count = 0; // How many times a local guard was evaluated
  volatile long int common_guard_count = 0; // How many times a common guard was evaluated
#define INCLOCAL(X) (local_guard_count++,(X))
#define INCCOMMON(X) (common_guard_count++,(X))
#else
#define INCLOCAL(X) (X)
#define INCCOMMON(X) (X)
#endif

// How the scheduler selects
// SELECT_RANDOM uses random selection,
// if not set, uses next action
#define SELECT_RANDOM // Random selection

// Four action modes. If not defined, three modes are used.
// In four modes, RUN mode is divided to GUARD and BODY
#define ACTIONMODE4

// Reading is supported
//#define READING

// Defining if and how execution has to be ended
// End if defined using Exe_status type and variable executor_status
//#define EXESTATUS

#define ACTION_MAX 1000000
#define EXECUTORS 10

// Next two defines should be powers of two
// This one has to be bigger than EXECUTORS
#define READY_LEN 16
// This one has to be bigger than EXECUTORS*2
#define COMPLETE_LEN 32

// This define is here to make it easier to implement
// later other means to handle errors.
#define Error fprintf

// Using compile-time flag -DEBUG makes errors to be printed to stdout, if
// LOG_FILE is not defined
#ifdef LOG_FILE
#define PRINTOUT log_file
#else
#ifdef EBUG
#define PRINTOUT stdout
#else
#define PRINTOUT stderr
#endif
#endif

// Actionmode with 3 states is simpler, but 4 states may be
// easier to adapt distribution of systems later on.
#ifdef ACTIONMODE4
typedef enum Actionmode {BODY, GUARD, DELETE, CREATE} Actionmode;
static char *modes[] = {"BODY", "GUARD", "DELETE", "CREATE"};
#define BODING BODY
#define GUARDING GUARD
#else
typedef enum Actionmode {RUN, DELETE, CREATE} Actionmode;
static char *modes[] = {"RUN", "DELETE", "CREATE"};
#define BODING RUN
#define GUARDING RUN
#endif

// Tri-state Booleans
typedef enum Tribool {FALSE, UNKNOWN, TRUE} Tribool;
static char *tribools[] = {"FALSE", "UNKNOWN", "TRUE"};
static char *bools[] = {"false", "true"};

// Ordered_Sets for participants
typedef struct Ordered_Set {
  uint size;
  Objectpointer objects[MAX_PARTICIPANTS];
} Ordered_Set;


struct Guarddata;
typedef struct Guarddata* Guarddatalist;

// 
// This is quite complex system...
// Firstly, each object has a list of guards that contain
// addresses to guard data. For each different pair of
// local guard and participant number, there is obe
// guard data record. This record has a list of actions
// that this position and value holds.
// In each action, there is a pointer to a corresponding
// guard data element.
// The benefit of this is that there is no need to compute
// the same local guard function for all actions.
//
typedef struct Guarddata {
  Guarddatalist next;  // one-way list
  Localfunction local_guard; // Address of the local guard function 
  bool guard_value;      // This is the most recent value of this local guard
  uint evaluation_time;  // If the guard is true, this is the time it was evaluated as such
  // my_actions contains points to an array of action pointers
  // actions_max is the length of this array (can vary dynamically)
  // action_count is the currrent number of actions in the list
  uint actions_max;
  uint action_count;
  Actionpointer *my_actions;
  // my_position is the index of the participant of the above action
  // That is, if the my_action[n] is accessed, its participant is my_position[n]
  uint *my_positions;
} Guarddata;

//
// Defines some vital information about a class
//
typedef struct Class_definition {
  uint size;		// Size of the class
  Initial_object initially; // Initializer of an object
  Destructor destroy;	// Destructor of an object
  Copy copy;		// Address of copy function
  char name[NAME_LENGTH]; // Name of the class, used for logging
} Class_definition;

typedef struct Object {
  Actionpointer locked;  // Locked by this action
  uint id;               // Id of an object (not necessary)
  Guarddatalist guards;  // Guards & actions of interest
  void *data;            // Actual application object address
  // These are common for all objects of the given type
  Class_descriptor descriptor; // Descriptor of the class of object
  Destructor destroy;    // "Destructor" of object
  Copy copy;             // Address of copy function; "copy constructor"
} Object;

typedef struct Action_definition {
  Actionfunction body;		// Address of the body
  Guardfunction common_guard;   // Address of the common guard
  Timings timing;		// Address of the timing routine
  uint parameter_count;		// Number of parameters
  uint participant_count;	// Number of participants
  Mask read_only;		// Mask for read-only participants of the action
  Localfunction local_guards[MAX_PARTICIPANTS];	// Local guards of participants
  char name[NAME_LENGTH];	// Name of the action, used for logging
} Action_definition;

typedef struct Action {
  Tribool is_locked;		// TRUE, if action is locked (it can't be executed)
				// FALSE, if action is not locked (it can be executed)
 				// UNKNOWN, if action was locked and we tried to unlock it but can't be sure,
 				// if somebody else is still locking it.
  volatile Tribool all_locals;	// The values of all local guards conjuncted -> either false, true or needs to be counted (unknown)
  volatile bool common_guard_valid;	// True, if the value of common guard is valid
  volatile bool common_guard_value;	// The value of the common guard

  volatile Actionmode mode;	// The current mode of the action
  Action_descriptor descriptor; // All other data is common for this action

  Actionpointer creator;	// The identity of the action creating this action (NULL - initialization code)
  uint live_participants;	// If smaller than the participant_count, the action is not yet ready
				// (or already going to die)
  uint parameters[MAX_PARTICIPANTS];			// Parameters of the action (discrete)
  Objectpointer participants[MAX_PARTICIPANTS];		// List of participants.
  Guarddatalist local_guarddata[MAX_PARTICIPANTS];	// Pointer to their local guards
  Ordered_Set party;		// Set of participants to make easier to find out core actions
				// e.g. exists for optimisation, also participants could be used for this
  uint id;			// Id of an action - not necessary for computation

  // Timing

  volatile uint timeout;	// The first possible time to execute this action
  volatile uint deadline;	// The last possible time to execute this action
  Timings_type times;		// Timing values for the action
} Action;

// Used when actions are duplicated
typedef struct Action_dup_list {
  struct Action_dup_list *next;
  Actionpointer action;
  uint count;
} Action_dup_list;

#ifdef EXESTATUS
typedef volatile enum Exe_status {EXECUTING, IDLE, EXIT, DEAD} Exe_status;
static Exe_status executor_status[EXECUTORS];
#endif

#ifdef EBUG
Actionpointer action_list[ACTION_MAX];
volatile uint action_count = 0;
#else
static Actionpointer action_list[ACTION_MAX];
static volatile uint action_count = 0;
#endif
static volatile uint action_ident = 0;
static volatile uint object_ident = 0;
static volatile uint create_count = 0;

static pthread_mutex_t creator_mutex;
static pthread_mutex_t ready_mutex;
static pthread_mutex_t dup_mutex;

static Actionpointer ready_queue[READY_LEN];
static volatile uint ready_first = 0;
static volatile uint ready_last = 0;

static pthread_mutex_t complete_mutex;

static Actionpointer complete_queue[COMPLETE_LEN];
static volatile uint complete_first = 0;
static volatile uint complete_last = 0;

#ifdef COUNT_MUTEX
static long int mutex_called = 0; // No functional purpose, just statistics
#endif
static sem_t ready_semaphore;
static sem_t ready_free_semaphore;
static sem_t complete_semaphore;
static sem_t complete_free_semaphore;

// Threads, but we do not want them to be available
// from other modules

static pthread_t executor_threads[EXECUTORS];
static uint executors;

#ifdef READING
static pthread_t reading_thread;
static bool reading_thread_active;

#include <termios.h>
#endif

//
// Ordered_set
//
// Implements ordered array of objectpoints to make it
// fast to determine if an action has subset of participants
// of another action
//
//typedef struct Ordered_Set {
//  uint size;
//  Objectpointer objects[MAX_PARTICIPANTS];
//} Ordered_Set;

// Add one object to the set
static void add_set(Ordered_Set *set, Objectpointer obj)
{
  uint i;
  for (i = 0; i < set->size; i++) {
    if (set->objects[i] > obj)
      break;
  }
  set->size++;
  for (uint k = set->size; k > i; k--) {
    set->objects[k] = set->objects[k-1];
  }
  set->objects[i] = obj;
}

// Initialize a set
static void make_set(Ordered_Set *set, Objectpointer participants[], uint count)
{
  set->size = 0;
  for (uint p = 0; p < count; p++) {
    if (participants[p] != NULL)
      add_set(set, participants[p]);
  }
}

// Check if 'sub' is a subset of 'set'
static bool is_subset(Ordered_Set *sub, Ordered_Set *set)
{
  if (sub->size > set->size)
    return false;
  uint k = 0;
  uint i = 0;
  while(i < sub->size && k < set->size) {
    if (sub->objects[i] < set->objects[k])
      return false;
    if (sub->objects[i] == set->objects[k]) {
      i++;
    }
    k++;
  }
  return i == sub->size;
}

//
// For internal timing, one tick is one millisecond
// Needed a) to prevent unnecessary looping and
// b) figuring out, when to stop simulation
//
void tick(long int nanos)
{
#ifdef __WIN32
  long int millis;
  millis = nanos / 1000000L;  // milliseconds
  if (millis < 1) {
    millis = 1;
  }
  Sleep(millis);
#else
  struct timespec time;
  time.tv_sec = 0; //seconds
  time.tv_nsec = nanos; // nanoseconds
  if (nanosleep(&time, NULL) == -1) {
    perror ("Nanosleep call\n");
  }
#endif
}


// size is the size of the data part of the object
// copy is the address of copy "constructor"
// destroy is the address of "destructor"

Class_descriptor create_class(char *name,
			      uint size,
			      Initial_object initially,
			      Copy copy,
			      Destructor destroy)
{
  Class_descriptor descriptor = malloc(sizeof(Class_definition));
  strlcpy(name, descriptor->name, (size_t)NAME_LENGTH);
  descriptor->size = size;
  descriptor->initially = initially;
  descriptor->copy = copy;
  descriptor->destroy = destroy;
  LOG2("Core: created class %s\n", descriptor->name);
  return descriptor;
}

// Creates an object
// Updating object_ident is a critical section, but since
// id is not really needed in computations, mutex is left out
// data is pointer to the actual contents of an object
Objectpointer create_object (Class_descriptor descriptor)
{
  Debug("Object creation is called\n");
  Objectpointer object = malloc(sizeof(Object));
  object->descriptor = descriptor;
  object->guards = NULL;
  object->data = malloc(descriptor->size);
  if (descriptor->initially != NULL) {
    (*descriptor->initially)(object->data);
  } else {
    char *filler = object->data;
    for(uint i = 0; i < descriptor->size; i++) {
      *filler++ = 0;
    }
  }
  object->id = object_ident++; // No functional purpose, no mutual exclusion
  object->locked = NULL;
  LOG4("Core: created object %d (%x), descriptor %s\n", object->id, object, descriptor->name);
  return object;
}

Objectpointer copy_object(Objectpointer old)
{
  //printf("In copyobject\n");
  Objectpointer newobject = create_object(old->descriptor);
  if (old->descriptor->copy != NULL) {
    //printf("given copy: copyobject\n");
    (*old->descriptor->copy)(old->data, newobject->data);
  } else {
    //printf("default copy: copyobject\n");
    char *filler1 = old->data;
    char *filler2 = newobject->data;
    for(uint i = 0; i < old->descriptor->size; i++) {
      *filler1++ = *filler2++;
    }
  }
  Debug("Out copy object\n");
  return newobject;
}


Timings_type default_timing(uint *param)
{
  Timings_type tim = {0};
  return tim;
}

Action_descriptor create_action_descriptor (char* name,
					    Actionfunction body,
					    Guardfunction common_guard,
					    Timings timing,
					    Mask read_only,
					    uint parameter_count,
					    uint participant_count,
					    ...)
{
  Action_descriptor descriptor = malloc(sizeof(Action_definition));
  strlcpy(name, descriptor->name, (size_t)NAME_LENGTH);
  descriptor->body = body;
  descriptor->common_guard = common_guard;
  if (timing == NULL) {
    timing = default_timing;
  }
  descriptor->timing = timing;
  descriptor->parameter_count = parameter_count;
  descriptor->participant_count = participant_count;
  descriptor->read_only = read_only;
  va_list ap;
  va_start(ap, participant_count);
  for (uint i = 0; i < participant_count; i++) {
    descriptor->local_guards[i] = va_arg(ap, Localfunction);
  }
  va_end(ap);
#ifdef LOG_FILE
  char line[VERYLONG], one_line[VERYLONG];
  sprintf(line, "Core: Created action %s. Body at %x, guard at %x, timing %x. Read-only mask %x, parameters %d, participants %d. Local guards: ", descriptor->name, body, common_guard, timing, read_only, parameter_count, participant_count);
  for (uint i = 0; i < participant_count; i++) {
    sprintf(one_line, "%x ", descriptor->local_guards[i]);
    strcat(line, one_line);
  }
  strcat(line, "\n");
  LOG1(line);
#endif
  return descriptor;
}

static void add_action_to_object(Objectpointer object, Actionpointer action, uint position);

static Actionpointer initialize_action(Actionpointer runner,
				       Action_descriptor descriptor,
				       uint parameters[],
				       Objectpointer participants[])
{
  Actionpointer action = (Action*) malloc(sizeof(Action));
  action->descriptor = descriptor;
  action->is_locked = TRUE;
  action->all_locals = TRUE;
  action->common_guard_value = true;
  action->common_guard_valid = true;
  action->timeout = 0;
  action->deadline = 0;
  action->live_participants = 0;
  action->times = (*action->descriptor->timing)(parameters);
  action->party.size = 0;  // The set of participants is empty
  for (uint i = 0; i < descriptor->parameter_count; i++) {
    action->parameters[i] = parameters[i];
  }
  for (uint i = 0; i < descriptor->participant_count; i++) {
    action->participants[i] = participants[i];
    action->local_guarddata[i] = NULL;
    if (participants[i]->locked == runner) {
      add_action_to_object(participants[i], action, i);
    }
  }
  make_set(&action->party, participants, descriptor->participant_count);
  action->mode = CREATE;
  action->creator = runner;
  pthread_mutex_lock(&creator_mutex);
  if (create_count + action_count == ACTION_MAX-1) {
    Error(PRINTOUT, "No more actions possible (number is %d)\n", create_count+action_count);
  } else {
    create_count++;
    action_list[ACTION_MAX-create_count] = action;
    action->id = action_ident++;
  }
#ifdef LOG_FILE
  char line[VERYLONG], one_line[VERYLONG];
  sprintf(line, "Core: Created action %d (%x), descriptor %s. ", action->id, action, descriptor->name);
  if (descriptor->parameter_count != 0) {
    strcat(line, "Parameters: ");
    for (uint i = 0; i < descriptor->parameter_count; i++) {
      sprintf(one_line, "%d, ", action->parameters[i]);
      strcat(line, one_line);
    }
  }
  strcat(line, "Participants: ");
  for (uint i = 0; i < descriptor->participant_count; i++) {
    sprintf(one_line, "%d (%x) class %s -", action->participants[i]->id, action->participants[i], action->participants[i]->descriptor->name);
    strcat(line, one_line);
  }
  strcat(line, "\n");
  LOG1(line);
#endif
  pthread_mutex_unlock(&creator_mutex);
  return action;
}

void *object_data(Objectpointer obj)
{
  return obj->data;
}

uint object_id(Objectpointer obj)
{
  return obj->id;
}

// This is called for actions whose all participants are available
// i.e. they all are locked for the action that calls this function.
//
// This procedure computes the value of the action guard;
// if needed, all_locals is first computed, then the
// actual common guard.
//
// The action is locked or selected for execution, when this procedure is called.
//
static void compute_full_action_guard(Actionpointer action)
{
  if (action->all_locals == UNKNOWN) {
    action->all_locals = TRUE;
    for (uint p = 0; p < action->descriptor->participant_count; p++) {
      if (action->local_guarddata[p] != NULL && !action->local_guarddata[p]->guard_value) {
	action->all_locals = FALSE;
	break;
      }
    }
  }
  if (action->all_locals == FALSE) {
    action->common_guard_value = false;
  } else {
    // Note that for all actions in mode DELETE, common_guard is NULL
#ifdef CHECK
    if (action->mode == DELETE && action->descriptor->common_guard != NULL) {
      Error(PRINTOUT, "Severe internal error - mode DELETE should imply common_guard is NULL\n");
    }
#endif
    action->common_guard_value =
      action->descriptor->common_guard == NULL
      || INCCOMMON((action->descriptor->common_guard)(action->parameters, action->participants));
  }
  action->common_guard_valid = true;
}

// This is called for actions whose guard might have been changed
// during the execution of the current (runner) action. Its guard can't
// be evaluated fully, since not all of its participants are locked for
// the calling action, but in same cases we can deduct something.
// The action (but not all of its participants) is locked when this procedure is called.
//
static void compute_partial_action_guard(Actionpointer action, bool old_value)
{
  // The new local guard is true
  switch (action->all_locals) {
  case FALSE:
    if (old_value) {
      // all_locals was false, and this local guard was true, so somebody else is keeping it down
      // Hence, the action is not enabled, but it's not decided here.
      // Do nothing.
      break;
    } else {
      // if all_locals was FALSE and this local guard was false,
      // then we do not know all_locals, and the common guard is not valid
      action->all_locals = UNKNOWN;
      action->common_guard_valid = false;
    }
    break;
  case UNKNOWN:  // No changes
    break;
  case TRUE:
#ifdef CHECK
    if (!old_value) {
      Error(PRINTOUT, "all_locals is true, but old_value is false - should never happen\n");
    }
#endif
    if (action->descriptor->common_guard == NULL) {
      // if all_locals was TRUE, and the common guard does not exist,
      // common guard value is TRUE and valid
      action->common_guard_value = true;
      action->common_guard_valid = true;
    } else{
      // Otherwise, the guard has to be evaluated
      action->common_guard_valid = false;
    }
    break;
  }
}

// A new action accesses this object
// Add to the list, but in case the list is not long enough,
// make it longer

static void add_action_to_object(Objectpointer object, Actionpointer action, uint position)
{
  Localfunction local_guard = action->descriptor->local_guards[position];
  uint current_time = (uint)time(NULL);
  Guarddatalist prev_gdl = NULL;
  Guarddatalist gdl = object->guards;
  while (gdl != NULL) {
    if (gdl->local_guard == local_guard) {
      break;
    }
    prev_gdl = gdl;
    gdl = gdl->next;
  }
  // If gdl is NULL, then we have to add guard data record the the list
  if (gdl == NULL) {
    gdl = malloc(sizeof(Guarddata));
    gdl->next = NULL;
    if (prev_gdl == NULL) {
      // First one
      object->guards = gdl;
    } else {
      prev_gdl->next = gdl;
    }
    gdl->local_guard = local_guard;
    Debug("Add action to object local guard\n");
    gdl->guard_value =
      gdl->local_guard == NULL || INCLOCAL((gdl->local_guard)(object));
    gdl->evaluation_time = current_time;
    gdl->actions_max = 0;
    gdl->action_count = 0;
    gdl->my_actions = NULL;
    gdl->my_positions = NULL;
  }
  // Now, gdl points to the record where to add action
  // For each local function there is a list of actions.
  // If the list is full, allocate more space.
  if (gdl->action_count >= gdl->actions_max) {
    if (gdl->actions_max == 0) {
      gdl->actions_max = 4;
    } else {
      gdl->actions_max *= 2;
    }
    Actionpointer *act_temp = calloc(gdl->actions_max, sizeof(Actionpointer));
    uint *uint_temp = calloc(gdl->actions_max, sizeof(uint));
    for (uint i = 0; i < gdl->action_count; i++) {
      act_temp[i] = gdl->my_actions[i];
      uint_temp[i] = gdl->my_positions[i];
    }
    free(gdl->my_actions);
    gdl->my_actions = act_temp;
    free(gdl->my_positions);
    gdl->my_positions = uint_temp;
  }
  gdl->my_actions[gdl->action_count] = action;
  gdl->my_positions[gdl->action_count] = position;
  gdl->action_count++;
  // Updates the timeout and deadline of the action
  if (gdl->guard_value) {
    uint timeout = action->times.local_timeouts[position];
    if (timeout != 0) {
      timeout += gdl->evaluation_time;
      if (action->timeout < timeout && timeout > current_time) {
	action->timeout = timeout;
	Debug ("Timeout set %u\n", timeout);
      }
    }
    uint deadline = action->times.local_deadlines[position];
    if (deadline != 0) {
      deadline += gdl->evaluation_time;
      if (action->deadline > deadline) {
	action->deadline = deadline;
	Debug ("Deadline set %u\n", deadline);
      }
    }
  }
  action->local_guarddata[position] = gdl;
  action->live_participants++;
  if (gdl->guard_value) {
    if (action->all_locals == TRUE) {
      if (action->descriptor->common_guard != NULL)
	action->common_guard_valid = false;
    }
  } else {
    action->all_locals = FALSE;
    action->common_guard_value = false;
    action->common_guard_valid = true;
  }    
}

// Makes a copy from a action.
// runner is the running action (needed to check the locks)
// participants is the list of new objects as participants

void copy_action(Actionpointer runner, Actionpointer original, Objectpointer participants[])
{
  initialize_action(runner,
		    original->descriptor,
		    original->parameters,
		    participants);
}

// Creates an new action

Actionpointer create_action(Actionpointer runner,
			    Action_descriptor descriptor,
			    ...)
{
  uint parameters[MAX_PARTICIPANTS];
  Object *ob[MAX_PARTICIPANTS];
  va_list ap;
  va_start(ap, descriptor);
  Debug("Create action, %d parameters, %d participants\n", descriptor->parameter_count, descriptor->participant_count);
  for (uint i = 0; i < descriptor->parameter_count; i++) {
    parameters[i] = va_arg(ap, uint);
  }
  for (uint i = 0; i < descriptor->participant_count; i++) {
    ob[i] = va_arg(ap, Objectpointer);
  }
  va_end(ap);
  Actionpointer action = initialize_action(runner,
					   descriptor,
					   parameters,
					   ob);
  return action;
}

uint action_id (Actionpointer ap)
{
  return ap->id;
}

//
// This action generates a new list of participants for the
// action to be created. It returns the number of new objects
// used in the new participant list. This number is used to
// determine, if the action has to be checked for duplicate
// copies.
//
static uint make_new_participant_list(uint original_count,
				      Objectpointer originals[],
				      Objectpointer dup_objects[],
				      uint count,
				      Objectpointer old_objects[],
				      Objectpointer new_objects[])
{
  uint used_duplicates = 0;
  for (uint i = 0; i < original_count; i++) {
    dup_objects[i] = originals[i];
    for (uint k = 0; k < count; k++) {
      if (originals[i] == old_objects[k]) {
	dup_objects[i] = new_objects[k];
	used_duplicates++;
	break;
      }
    }
  }
  return used_duplicates;
}

// We try to duplicate objects (or tuples of objects)
// The first parameter is the action making the call,
// the second one is the object count, the rest are
// are the objects to be duplicated
// New objects are stored on the second parameter that shall
// have enough room for new objects

void duplicate_objects(Actionpointer runner, Objectpointer new_objects[], uint count, ...)
{
  Objectpointer dup_objects[MAX_PARTICIPANTS];
  Objectpointer old_objects[MAX_PARTICIPANTS];
  uint index;
  va_list arg;
  va_start (arg, count);
  Action_dup_list *created = NULL;

  // This part generates two arrays: the first one
  // contains old objects to be duplication, and
  // the second one contains their duplicated
  // values. Parameter count gives the number of
  // participants to be duplicated; it is then
  // followed by thier indices in the calling action

  pthread_mutex_lock(&dup_mutex);
  LOG3("Start duplicate by action %d of %s\n", runner->id, runner->descriptor->name);
  uint i = 0;
  for (i = 0; i < count; i++) {
    index = va_arg(arg, uint);
    old_objects[i] = runner->participants[index];
    new_objects[i] = copy_object(old_objects[i]);
  }
  va_end(arg);
  for (i = 0; i < count; i++) {
    //Debug("Making %d new actions from old object %d\n", old_objects[i]->action_count, old_objects[i]->id);
    Guarddatalist gdl = old_objects[i]->guards;
    while (gdl != NULL) {
      uint used_duplicates = 0;
      for (uint a = 0; a < gdl->action_count; a++) {
	if (gdl->my_actions[a]->mode == DELETE) {
	  continue;
	}
	used_duplicates =
	  make_new_participant_list(gdl->my_actions[a]->descriptor->participant_count,
				    gdl->my_actions[a]->participants, 
				    dup_objects,
				    count,
				    old_objects,
				    new_objects);
#ifdef CHECK
	if (used_duplicates == 0) {
	  Error(PRINTOUT, "Internal error. New participant list did not include new objects. Action id is %d\n", runner->id);
	  continue;
	}
#endif
	// If the number of duplcates used in making the action is
	// one, then other duplicates of the same action are not possible
	if (used_duplicates == 1) {
	  copy_action(runner, gdl->my_actions[a], dup_objects);
	} else {
	  // 
	  // In this case, there are potentially several duplicates coming up
	  //
	  Action_dup_list *prev = NULL;
	  Action_dup_list *current = created;
	  // 
	  // Search for the previous duplicate of this actions
	  //
	  while (current != NULL) {
	    if (current->action == gdl->my_actions[a]) {
	      // This action has been duplicated already
	      break;
	    }
	    prev = current;
	    current = current->next;
	  }
	  if (current == NULL) {
	    //
	    // If current is NULL, this is the first occurrence of this
	    // action. New list element is made, and also the action
	    // is made
	    //
	    copy_action(runner, gdl->my_actions[a], dup_objects);
	    current = (Action_dup_list*) malloc(sizeof(Action_dup_list));
	    if (prev == NULL) {
	      created = current;
	    } else {
	      prev->next = current;
	    }
	    current->next = NULL;
	    current->action = gdl->my_actions[a];
	    current->count = used_duplicates-1; // -1 because we just made the action
	  } else {
	    //
	    // Current is not null, so we decrement its usage, and
	    // we don't make any actions
	    //
	    current->count--;
	    if (current->count == 0) {
	      // 
	      // if the count is 0, this was the last possible duplicate action, and
	      // we can remove its data from the list
	      //
	      if (prev == 0) {
		created = current->next;
	      } else {
		prev->next = current->next;
	      }
	      current->next = 0;
	      free(current);
	    }
	  }
	}
      }
      gdl = gdl->next;
    }
  }
#ifdef CHECK
  if (created != NULL) {
    Error (PRINTOUT, "Core internal error: The duplicate list was not empty.\n");
  }
#endif
  LOG3("Core: End duplicate by action %d of %s\n", runner->id, runner->descriptor->name);
  pthread_mutex_unlock(&dup_mutex);
}

// Marks the action to be deleted by setting its mode to DELETE
void delete_action(Actionpointer action)
{
  action->mode = DELETE;
  action->all_locals = TRUE;
  action->common_guard_value = true;
  action->common_guard_valid = true;
}

// This is called from delete_object, if action is
// listed in potential actions accessing the object
// This marks the action to be deleted
void remove_participant(Actionpointer action, uint pos)
{
  // Since delete_object is invoked by an action that has the target object
  // as an parameter, all actions in object's accessing list
  // have been locked. Hence, it is safe to assign NULL
  // into the participant list removing the parameter object.
  // This assignment alone enforces deletion of the action
  // if ever scheduled again, but we
  // change actions mode to DELETE.

  delete_action(action);
  action->participants[pos] = NULL;
  action->local_guarddata[pos] = NULL;
  action->live_participants--;
  action->mode = DELETE;
  make_set(&action->party, action->participants, action->descriptor->participant_count);
  Debug("Remove participant unknownlocks %d\n", action->id);
  action->is_locked = UNKNOWN;  // This has to be the last assignment (scheduler will otherwise start too early)
}

// If an object is deleted, all actions accessing it
// has to be deleted, too.
// So, they are marked as "delete", but actual destruction
// takes place when they are selected for execution

void delete_object(Objectpointer object)
{
  Debug ("Deleting object %d\n", object->id);
  Guarddatalist prev_gdl = NULL;
  Guarddatalist gdl = object->guards;
  while (gdl != NULL) {
    for(uint a = 0; a < gdl->action_count; a++) {
      remove_participant(gdl->my_actions[a], gdl->my_positions[a]);
    }
    free(gdl->my_actions);
    gdl->my_actions = NULL;
    free(gdl->my_positions);
    gdl->my_positions = NULL;
    prev_gdl = gdl;
    gdl = gdl->next;
    free(prev_gdl);
    prev_gdl = NULL;
  }
  if (object->destroy != NULL && object->data != NULL) {
    Debug("Data at %x destroyed\n", object->data);
    (object->destroy)(&object->data);
  }
  if (object->data != NULL) {
    free(object->data);
  }
  object->data = NULL;
  object->locked = NULL;
  free(object);
}

void unlock_object(Objectpointer object)
{
  if (object == NULL) {
    return;
  }
  Guarddatalist gdl = object->guards;
  while (gdl != NULL) {
    for (uint a = 0; a < gdl->action_count; a++) {
      gdl->my_actions[a]->is_locked = UNKNOWN;
      Debug("Action %d is unknownlocked by unlock object\n", gdl->my_actions[a]->id);
    }
    gdl = gdl->next;
  }
  object->locked = NULL;
}

// Called by delete_action_internal
// Action is being removed, so remove reference to it
// in this object, which is locked for it

void remove_action_from_object(Objectpointer object, Actionpointer action, uint position)
{
  Debug("Removing action %d from object %d\n", action->id, object->id);
  bool found = false;
  Guarddatalist prev_gdl = NULL;
  Guarddatalist gdl = object->guards;
  while (gdl != NULL) {
    if (found) {
      break;  // Is not in this list, skip
    }
    for (uint a = 0; a < gdl->action_count; a++) {
      if (gdl->my_actions[a] == action) {
	gdl->action_count--;
	if (a < gdl->action_count) {
	  gdl->my_actions[a] = gdl->my_actions[gdl->action_count];
	  gdl->my_positions[a] = gdl->my_positions[gdl->action_count];
	}
	gdl->my_actions [gdl->action_count] = NULL;
	gdl->my_positions [gdl->action_count] = 0;
	found = true;
	break;
      }
    }
    if (gdl->action_count == 0) {
      if (prev_gdl == 0) {
	object->guards = gdl->next;
      } else {
	prev_gdl->next = gdl->next;
      }
      free(gdl);
      gdl = NULL;
    } else {
      prev_gdl = gdl;
      gdl = gdl->next;
    }
  }
  if (object->guards == NULL) {
    // Safe to call delete_object, since this was its last action
    Debug("Delete object %d in remove action\n", object->id);
    delete_object(object);
  } else {
    unlock_object(object);
  }
}

static void delete_action_internal(Actionpointer action)
{
  Debug("Deleting action %d, locked %d\n", action->id, action->is_locked);
  action->common_guard_value = true;
  action->common_guard_valid = true;
  action->all_locals = TRUE;
  for (uint p = 0; p < action->descriptor->participant_count; p++) {
    if(action->local_guarddata[p] == NULL) {
      // This was never made a proper participant
      unlock_object(action->participants[p]);
      action->participants[p] = NULL;
    }
    if(action->participants[p] != NULL) { // Already removed if NULL
      remove_action_from_object(action->participants[p], action, p);
      action->participants[p] = NULL;
      action->local_guarddata[p] = NULL;
    }
  }
  action->live_participants = 0;
  Debug("Action %d is freed by delete action internal\n", action->id);
  action->is_locked = FALSE;
}

// This function locks participants for exclusive use of this
// action. Locking participants disables actions that
// have common participants with this action
// This is called from scheduler only

static void lock_action(Actionpointer action)
{
  Debug ("Lock action locks action %d\n", action->id);
  action->is_locked = TRUE;

  // Go through all participants of the action (including the action itself)
  
  for (uint p = 0; p < action->descriptor->participant_count; ++p) {
    // Lock the participants
    Objectpointer object = action->participants[p];
    if (object == NULL) {
#ifdef CHECK
      // Enters mode DELETE (participant missing)
      if (action->mode != DELETE) {
	// Anyway, this is a double check - this should have been marked earlier
	Error(PRINTOUT,"Core internal error: Lock action wiht null participants -> deleting %d\n", action->id);
	action->mode = DELETE;
      }
#endif
      continue;
    }
    // Lock the object and go through all actions of a participant and mark them as locked
#ifdef CHECK
    if (object->locked != NULL) {
      Error(PRINTOUT, "Core internal error: Attempt to lock object %d by action %d; object locked to action %d\n",
	    action->id, object->id, object->locked->id);
    }
#endif
    object->locked = action;
    
    Guarddatalist gdl = object->guards;
    while (gdl != NULL) {
      for(uint a = 0; a < gdl->action_count; a++) {
	// The target is locked
	Debug ("Lock action locks 'side' action %d\n", gdl->my_actions[a]->id);
	gdl->my_actions[a]->is_locked = TRUE;
      }
      gdl = gdl->next;
    }
  }
}

//
// Unlocks participants of the action, newly made actions
// and the action itself.
// This is executed by the scheduler only
//
static void unlock_action (Actionpointer runner)
{
  // Unlocks actions in creation list
  if (create_count > 0) {
    //pthread_mutex_lock(&creator_mutex);
    for (uint c = ACTION_MAX - create_count; c < ACTION_MAX; c++) {
      if (action_list[c]->creator == runner)
	action_list[c]->creator = NULL;
    }
    //pthread_mutex_unlock(&creator_mutex);
  }
  // Unlocks objects (participants)
  for (uint p = 0; p < runner->descriptor->participant_count; p++) {
    unlock_object(runner->participants[p]);
  }
  Debug("Action %d is unlocked by unlock actions\n", runner->id);
  runner->is_locked = FALSE;
}

static void enqueue_scheduler(Actionpointer runner)
{
  sem_wait(&complete_free_semaphore);
  pthread_mutex_lock(&complete_mutex);
  complete_queue[complete_last++] = runner;
  complete_last &= (COMPLETE_LEN-1);
  pthread_mutex_unlock(&complete_mutex);
  sem_post(&complete_semaphore);
}

#ifdef READING
//
// This procedure is called from "interrupt" routines only
// It evaluates the local guards of the object, but does
// not expect to face problems like deleted object.
// This is executed concurrently with executor prosesses, i.e.,
// there is no exclusive access for the object
//
static void evaluate_local_guards_of_object(Objectpointer object)
{
  if(object == NULL) {
    return;
  }
  //
  // Potential changes in values - we would not be here unless this is the case
  //
  Guarddatalist gdl = object->guards;
  while(gdl != NULL) {
    bool old_value = gdl->guard_value;
    //
    // Note the cases:
    // If there is no local guard, it is evaluated as true
    //
    Debug("Evaluate local guards of object local guard\n");
    gdl->guard_value =
      gdl->local_guard == NULL || INCLOCAL((gdl->local_guard)(object));
    if (!gdl->guard_value) {
      //
      // If the new value is false, the local (and common) guard(s) will not
      // evaluate true unless the object is changed again.
      //
      if (!old_value) {
	// If old and new values are false, nothing changes, get next guard
	continue;
      } else {
	// Old local guard value was true, so the guards have to be set false
	for (uint a = 0; a < gdl->action_count; a++) {
	  Actionpointer action = gdl->my_actions[a];
	  if (action->mode == DELETE) {
	    // Action marked as delete should be always enabled to get rid of it
	    continue;
	  }
	  action->all_locals = FALSE;
	  action->common_guard_value = false;
	  action->common_guard_valid = true;
	}
      }
    } else {
      //
      // The new value is true. Hence, also the timeout has to be checked.
      // Timeout may differ for otherwise identical actions, hence its value
      // is taken from the action descriptions.
      //
      uint current_time = (uint)time(NULL);
      //
      // However, we have to store the time of evaluation to make
      // action duplication work correctly.
      //
      gdl->evaluation_time = current_time;
      //
      // This loop is necessary even if old_value is true,
      // since we do not know what happens with the common
      // guard. All we know is that this object has changed
      // somehow, which causes potential change on common guard also
      //
      for (uint a = 0; a < gdl->action_count; a++) {
	Actionpointer action = gdl->my_actions[a];
	if (action->mode == DELETE) {
	  continue;
	}
	uint timeout = 0;
	if ((timeout = action->times.local_timeouts[gdl->my_positions[a]]) != 0) {
	  timeout += current_time;
	  if (action->timeout < timeout) {
	    action->timeout = timeout;
	    Debug ("Timeout set %u\n", timeout);
	  }
	}
	compute_partial_action_guard(action, old_value);
	Debug("Action %d evaluated: valid %d, value %d, all locals %x\n", action->id, action->common_guard_valid, action->common_guard_value, action->all_locals);
      } // inmost for
    }
    gdl = gdl->next;
  } // while
}
#endif

static void post_evaluation(Actionpointer runner,
			    Mask deleted,
			    Mask unchanged)
{
  Debug("Unlocking %d, unchanged %x, delete %x\n", runner->id, unchanged, deleted);

  // Original place of create unlock
  //if (create_count > 0) {
  //  pthread_mutex_lock(&creator_mutex);
  //  for (uint c = ACTION_MAX - create_count; c < ACTION_MAX; c++) {
  //    if (action_list[c]->creator == runner)
  //	action_list[c]->creator = NULL;
  //  }
  //  pthread_mutex_unlock(&creator_mutex);
  //}

#ifdef NEVER
  if (deleted != 0) { // participant(s) deleted
    for(uint p = 0; p < runner->descriptor->participant_count; p++) {
      if ((deleted & (1 << p)) != 0) {
	delete_object(runner->participants[p]);
	deleted &= ~(1 << p);
	if (deleted == 0)
	  break;
      }
    }
  }
#endif
  for (uint p = 0; p < runner->descriptor->participant_count; p++) {
    Objectpointer object = runner->participants[p];
    if (object == NULL) {
      continue;
    }
    bool evaluate = (unchanged & (1 << p)) == 0;  // Updated
    bool del = (deleted & (1 << p)) != 0; // Deleted
    if (evaluate || del) {
      //
      // Potential changes in values
      //
      Guarddatalist gdl = object->guards;
      while(gdl != NULL) {
	bool old_value = gdl->guard_value;
	//
	// Note the cases:
	// If the participant is deleted, value of its local guard is set true
	// If there is no local guard, it is evaluated as true
	// Only if both of above are false, we have to evaluate the real local guard function
	//
	Debug("Post evaluation local guard, gdl = %x\n", gdl);
	gdl->guard_value =
	  del || gdl->local_guard == NULL || INCLOCAL((gdl->local_guard)(object));
	if (!gdl->guard_value) {
	  //
	  // If the new value is false, the local guard will not evaluate as true
	  // unless the object is changed again.
	  //
	  if (!old_value) {
	    gdl = gdl->next;
	    continue; // If old and new values are false, nothing changes; proceed with the next guard
	  } else {
	    // Old local guard value was true, so the guards have to be set false
	    for (uint a = 0; a < gdl->action_count; a++) {
	      Actionpointer action = gdl->my_actions[a];
	      if (action->mode == DELETE) {
		// Action marked as delete should be always enabled to get rid of it
		continue;
	      }
	      action->common_guard_value = false;
	      action->common_guard_valid = true;
	      action->all_locals = FALSE;
	    }
	  }
	} else {
	  //
	  // The new value is true. Hence, also the timeout has to be checked.
	  // Timeout may differ for otherwise identical actions, hence its value
	  // is taken from the action descriptions.
	  //
	  uint current_time = (uint)time(NULL);
	  if (!old_value) {
	    // However, we have to store the time of evaluation to make
	    // action duplication work correctly.
	    // The value is not updated, if old guard was true
	    gdl->evaluation_time = current_time;
	  }
	  //
	  // This loop is necessary even if old_value is true,
	  // since we do not know what happens with the common
	  // guard. All we know is that this object has changed
	  // somehow, which causes potential change on common guard also
	  //
	  for (uint a = 0; a < gdl->action_count; a++) {
	    Actionpointer action = gdl->my_actions[a];
	    // Local guards of deleted participants are considered
	    // true. So, we check here if this is the case, and
	    // delete all actions that has the corresponding
	    // object as participant
	    if (del) {
	      delete_action(action);
	      continue;
	    }
	    if (action->mode == DELETE) {
	      continue;
	    }
	    uint timeout = 0;
	    if ((timeout = action->times.local_timeouts[gdl->my_positions[a]]) != 0) {
              // Mutual exclusion needed ?
	      timeout += current_time;
	      if (action->timeout < timeout) {
		action->timeout = timeout;
		Debug ("Timeout set %u\n", timeout);
	      }
	    }
	    // If all parameters are present, guard of the action can be evaluated fully
	    if (is_subset(&action->party, &runner->party)) {
	      switch (action->all_locals) {
	      case FALSE:
		// If all_locals was FALSE, and old_value was true, then somebody else
		// is keeping it down, so no use to compute it again.
		if (old_value) {
		  break;
		}
		// But, if all_locals was FALSE and old_value was false, then
		// the current guard might been the local guard keeping it down, so
		// all_locals has to be re-evaluated.
		// Continued intentionally to the next alternative
	      case UNKNOWN:
		// If all_locals is UNKNOWN, then compute the new value
		action->all_locals = TRUE;
		for (uint p = 0; p < action->descriptor->participant_count; p++) {
		  if (action->local_guarddata[p] != NULL && !action->local_guarddata[p]->guard_value) {
		    action->all_locals = FALSE;
		    break;
		  }
		}
		break;
	      case TRUE:
		// If all_locals was true, then its value is not changed, no need to compute it
		break;
	      }
	      if (action->all_locals == TRUE) {
		if (action->descriptor->common_guard == NULL) {
		  action->common_guard_valid = true;
		  action->common_guard_value = true;
		  action->mode = BODING;
		} else {
		  action->common_guard_valid = false;
		  action->mode = GUARDING;
		}
	      } else {
		  action->common_guard_valid = true;
		  action->common_guard_value = false;
	      }
	    } else {
	      Debug("Evaluate partially the guard of %d by %d\n", action->id, runner->id);
	      compute_partial_action_guard(action, old_value);
	    }
	    Debug("Action %d evaluated: valid %d, value %d, all locals %x\n", action->id, action->common_guard_valid, action->common_guard_value, action->all_locals);
	  } // inmost for
	}
	gdl = gdl->next;
      } // while
    }
  } // outmost for
}

static Actionpointer get_next_action(uint ident)
{
  Actionpointer action = NULL;
#ifdef EXESTATUS
  executor_status[ident] = IDLE;
#endif
  sem_wait(&ready_semaphore);
  pthread_mutex_lock(&ready_mutex);
#ifdef COUNT_MUTEX
  mutex_called++;
#endif
  action = ready_queue[ready_first++];
  ready_first &= (READY_LEN-1);
  pthread_mutex_unlock(&ready_mutex);
  sem_post(&ready_free_semaphore);
#ifdef EXESTATUS
  executor_status[ident] = EXECUTING;
#endif
  return action;
}

// This is the executor that makes everything
// Actually, it simulates one application processor

static void* executor(void* v)
{
  uint ident = (uint)(long)v;  // The ident of the executor (0..N-1)
  // Actions to concern

  Actionpointer runner = NULL;  // Current action to be run
  Mask unchanged = ~0U;  // Corresponds to no changed actions
  Mask deleted = 0;
#ifdef STATISTICS
  long int ec[4] = {0,0,0,0}; // Times in different modes
#endif

  LOG4("Executor %d: started, actions %d, create count %d\n", ident, action_count, create_count);

  while((runner  = get_next_action(ident))!= NULL) {
    LOG5("Executor %d: action %d (%s), mode %s\n", ident, runner->id, runner->descriptor->name, modes[runner->mode]);
#ifdef STATISTICS
    ec[runner->mode]++;  // Just for statistics, not functional purpose
#endif
    unchanged = ~0U;
    deleted = 0;

    switch (runner->mode) {
#ifdef ACTIONMODE4
    case GUARD:
#else
    case RUN:
      if (!runner->common_guard_valid) {
#endif
	Debug("Guard\n");
	compute_full_action_guard(runner);
	if (!runner->common_guard_value) {
	  LOG4("Executor %d: action %d (%s), guard false\n", ident, runner->id, runner->descriptor->name);
	  // The guard was false, get the next action
	  break;
	}
#ifndef ACTIONMODE4
      }
#else
      // Continues intentionally to the next alternative
    case BODY:
#endif
      Debug("Body executed\n");
      runner->descriptor->body(runner->parameters, runner->participants, &unchanged, &deleted, runner);
      post_evaluation(runner, deleted, unchanged);
      if (runner->mode != DELETE) {
	// Next action, if this one is not deleted
	break;
      }
      // Continues intentionally to the next alternative
    case DELETE:
      // Mode is DELETE
      LOG4("Executor %d: deleting action %d (%s):\n", ident, runner->id, runner->descriptor->name);
      delete_action_internal(runner);
      break;
    }
    LOG6("Executor %d: Runner %d (%s), deleted %d, unchanged %X\n", ident,  runner->id, runner->descriptor->name, deleted, unchanged);
#ifdef EXESTATUS
    executor_status[ident] = EXIT;
#endif
    enqueue_scheduler(runner);
  }
#ifdef STATISTICS
#ifdef ACTIONMODE4
  printf("Executor %d: %d rounds (%d guards, %d bodies, %d deletes)\n", ident, ec[0]+ec[1]+ec[2], ec[GUARD], ec[BODY], ec[DELETE]);
  LOG6("Executor %d: %d rounds (%d guards, %d bodies, %d deletes)\n", ident, ec[0]+ec[1]+ec[2], ec[GUARD], ec[BODY], ec[DELETE]);
#else
  printf("Executor %d: %d rounds (%d run, %d deletes)\n", ident, ec[0]+ec[1], ec[RUN], ec[DELETE]);
  LOG5("Executor %d: %d rounds (%d run, %d deletes)\n", ident, ec[0]+ec[1], ec[RUN], ec[DELETE]);
#endif
#endif
#ifdef EXESTATUS
  executor_status[ident] = DEAD;
#endif
  LOG2("Executor %d exits\n", ident);
  return 0;
} // End of executor

// Selects the next action to be executed
// Returns NULL if there is not any
// Works actually a lot like a monitor...
// This is called by the scheduler only
//
static Actionpointer select_next_action(uint *timeouts)
{
  Actionpointer action = NULL;
  uint first_selected = 0;
  uint selected = 0;
  uint num_of_locked = 0;

  if (action_count == 0) {
    return NULL;
  }
#ifdef SELECT_RANDOM
  first_selected = rand() % action_count;
#else
  first_selected = (selected + 1 ) % action_count;
#endif
  selected = first_selected;
  do {
    action = action_list[selected];
    uint current_time = (uint)time(NULL);
    if (action->timeout != 0 && current_time < action->timeout) {
      (*timeouts)++;
      LOG5("Scheduler: Timeout %u not passed at %u by action %i (%s)\n", action->timeout, current_time, action->id, action->descriptor->name);
    } else {
#ifdef EBUG
      if (action->timeout != 0)
	Debug ("Timeout %u passed at %u of action %i\n", action->timeout, current_time, action->id);
#endif
      if (action->is_locked == UNKNOWN) {
	//
	// This part finds out of action is locked or not.
	// First it defaults that the action is not locked, and then
	// if any of its participants is locked, locks the action
	//
	Debug ("Select next action unlocks action %d\n", action->id);
	action->is_locked = FALSE;
	for (uint p = 0; p < action->descriptor->participant_count; p++) {
	  if (action->participants[p] != NULL && action->participants[p]->locked != NULL) {
	    Debug ("Select next action locks action %d\n", action->id);
	    action->is_locked = TRUE;
	    break; // Exits for
	  }
	}
      }
      // 
      // If the action is not locked, it can potentially be executed
      //
      if (action->is_locked == FALSE) {
	if (!action->common_guard_valid || action->common_guard_value) {
	  //
	  // Action guard is true or unknown
	  // Action is removed from its position, the last action
	  // takes its place, and the last position is cleared
	  // Note that action_count is decremented before assignments
	  //
	  action_count--;
	  if (selected != action_count) {
	    action_list[selected] = action_list[action_count];
	  }
	  action_list[action_count] = NULL;
#ifdef ACTIONMODE4
	  if (action->mode != DELETE)
	    if (action->common_guard_valid)
	      action->mode = BODY;
	    else
	      action->mode = GUARD;
#endif
	  return action;
	}
      }
    } // end timeout
    // Try next one, jump to begining if action count exeeded.
    selected++;
    if (selected >= action_count) {
      selected = 0;
    }
  } while (selected != first_selected);
  return NULL;
}

// Action to be created in parts has finally been finished, so
// it will be moved to active action list
//
static void move_create_action_to_action_list(Actionpointer action, uint c)
{
  action_list[action_count] = action;
  if (c != ACTION_MAX - create_count) {
    action_list[c] = action_list[ACTION_MAX - create_count];
  }
  action_list[ACTION_MAX - create_count] = NULL;
  action_count++;
  create_count--;
}

#ifdef EXESTATUS
static void exe_status(uint exe[])
{
  exe[EXECUTING] = 0;
  exe[IDLE] = 0;
  exe[EXIT] = 0;
  exe[DEAD] = 0;
  for (uint i = 0; i < executors; i ++) {
    exe[executor_status[i]]++;
  }
}
#endif

//
// This is the scheduler.
// It is simulated by a thread
//

static void *scheduler()
{
  Actionpointer action = NULL;
  bool again = true;
#ifndef EXESTATUS
  bool history = true;
#endif
  uint nowork = 0;
  uint exe[4];
  uint sel_ok = 0;
#ifdef STATISTICS
  uint in_cr = 0;
  uint sel_null = 0;
#endif
  uint que = 0;
  uint timeouts = 0;
  do {
    if (create_count > 0) {
#ifdef STATISTICS
      in_cr++;
#endif
      pthread_mutex_lock(&creator_mutex);
      Debug ("Create actions found\n");
      for (uint c = ACTION_MAX - create_count; c < ACTION_MAX; ++c) {
	action = action_list[c]; // Just to make it easier to read
	if (action->creator != NULL) {
	  Debug ("Creator of action %d is not null\n", action->id);
	  // This is still ongoing creation process, skip for next
	  continue;
	}
	if (action->mode != CREATE) {
	  move_create_action_to_action_list(action, c);
	  continue;
	}
	// Is it in the creating state and lock is open
	bool lock_number = false;
	for(uint p = 0; p < action->descriptor->participant_count; p++) {
	  if (action->local_guarddata[p] == NULL) {
	    if (action->participants[p]->locked == NULL) {
	      add_action_to_object(action->participants[p], action, p);
	    } else {
	      lock_number = true;
	    }
	  } else {
	    Debug ("Action %d in create state, participant %d present\n", action->id, p);
	    if (action->participants[p]->locked != NULL)
	      lock_number = true;
	  }
	}
	// Not all actions yet present ?
	if (action->live_participants != action->descriptor->participant_count) {
	  // Next case, this is not yet completed
	  continue;
	}
	action->mode = GUARDING;
	if (lock_number) {
	  Debug ("Select next action locks newly created action %d\n", action->id);
	  action->is_locked = TRUE;
	} else {
	  Debug ("Select next action unlocks newly created action %d\n", action->id);
	  action->is_locked = FALSE;
	}
	move_create_action_to_action_list(action, c);
      }
      pthread_mutex_unlock(&creator_mutex);
    }
    timeouts = 0;
    //
    // The next action is selected
    //
    action = select_next_action(&timeouts);
    if (action != NULL) {
      // 
      // There is an action to execute
      //
      sel_ok++;
      LOG3("Scheduler: Action queued for execution %d (%s)\n", action->id, action->descriptor->name);
      lock_action(action);
      nowork = 0;
      Debug("Scheduler ready sem wait\n");
      sem_wait(&ready_free_semaphore);  // Wait for free room in scheduler queue
      Debug("Scheduler ready sem continue\n");
      ready_queue[ready_last++] = action;
      ready_last &= (READY_LEN-1);
      sem_post(&ready_semaphore);  // Inform that there is something in the queue
    } else {
      if (timeouts != 0
#ifdef READING
	  || reading_thread_active
#endif
	  ) {
	tick(10000000L); // Time passes (10 ms)
      } else {
#ifdef STATISTICS
	sel_null++;
#endif
#ifdef EXESTATUS
	if (create_count == 0) {
	  exe_status(exe);
	  Debug("Exe EXECUTING %d, IDLE %d, EXIT %d, DEAD %d ready first and last %d, %d\n", exe[EXECUTING], exe[IDLE], exe[EXIT], exe[DEAD], ready_first, ready_last);
	  again = exe[EXECUTING] + exe[EXIT] > 0 || ready_first != ready_last;
	  if (!again) {
	    Debug("Complete first and last: %d, %d; create count %d nowork %d\n", complete_first, complete_last, create_count, nowork);
	  again = !(complete_first == complete_last && create_count == 0 && ++nowork > 3);
	  }
	  tick(10000); // Just to make time pass a bit
	} else {
	  Debug("Action is %x, createcount %d\n", action, create_count);
	}
#else
	history = again;
	again = sel_ok != que || create_count != 0; // || ++nowork <= 5;
	if (create_count != 0) {
	  tick(10000);
	}
#endif
      }
    }
    //
    // Remove actions from completed queue
    //
    while (complete_first != complete_last) {
      // There is something in the queue
      que++;
      Debug("Scheduler complete sem wait\n");
      sem_wait(&complete_semaphore);
      Debug("Scheduler complete sem continue\n");
      action = complete_queue[complete_first++];
      LOG3("Scheduler: Action finished %d (%s)\n", action->id, action->descriptor->name);
      complete_first &= (COMPLETE_LEN-1);
      sem_post(&complete_free_semaphore);
      unlock_action(action);
      if (action->mode == DELETE && action->live_participants == 0) {
	free(action);
	action = NULL;
      } else {
	action_list[action_count++] = action;
	again = true;
      }
    }
  } while(again
#ifndef EXESTATUS
	  || history
#endif
	  );
#ifdef STATISTICS
  printf("Creation part %d, action found %d action null %d queue actions %d\n", in_cr, sel_ok, sel_null, que);
#ifdef COUNT_MUTEX
  printf("Action count %d, create_count %d mutex called %d\n", action_count, create_count, mutex_called);
#else
  printf("Action count %d, create_count %d\n", action_count, create_count);
#endif
#endif
  // NULLs in the queue stops the executors
  for (uint i = 0; i < executors; i++) {
    ready_queue[ready_last++] = NULL;
    ready_last &= (READY_LEN-1);
    sem_post(&ready_semaphore);
  }
#ifdef CHECK
  for (uint i = ACTION_MAX - create_count; i < ACTION_MAX; i++) {
    if (action_list[i]->mode == CREATE) {
      Actionpointer t = action_list[i];
      Debug("Action %d in create mode. Creator is %x, locked is %s, participant count %d, live participants %d\n",
	     t->id, t->creator, tribools[t->is_locked], t->descriptor->participant_count, t->live_participants);
    }
  }
  tick(100000000L); //Wait for executors to die
  printf("Action    lock  locals valid value mode\n");
  for (uint i = 0; i < action_count; i++) {
    Actionpointer t = action_list[i];
    if (t->is_locked == FALSE && t->common_guard_valid && !t->common_guard_value)
      continue;
    printf("%6d%8s%8s%6s%6s %s\n", t->id, tribools[t->is_locked], tribools[t->all_locals], bools[t->common_guard_valid], bools[t->common_guard_value], modes[t->mode]);
  }
#endif
  return 0;
}

// Timing routines
void action_timeout_absolute(Actionpointer action, uint absolute_time)
{
  uint current_time = (uint)time(NULL);
  if (action->timeout < absolute_time && current_time < absolute_time) {
    action->timeout = absolute_time;
  }
}

void action_timeout_relative(Actionpointer action, uint relative_time)
{
  uint current_time = (uint)time(NULL);
  action_timeout_absolute(action, current_time + relative_time);
}

#ifdef READING
// Keep the next on power of two
#define READSIZE 1024
typedef struct Reading {
  char buffer[READSIZE];
  uint in_index;
  uint out_index;
} Reading;

static Reading read_contents;

Objectpointer reading_object;

// This is the body of the reading action
static void* reader_body()
{
  // Terminal i/o -> read one char
  int char_read;
  Reading* reader = (Reading*)object_data(reading_object);
  reader->in_index = 0;
  reader->out_index = 0;

#ifndef _WIN32
  struct termios oldt, newt;
  tcgetattr(0, &oldt);
  newt = oldt;
  newt.c_lflag &= ~(ICANON | ECHO);
  newt.c_cc[VMIN] = 1;
  newt.c_cc[VTIME] = 0;
  tcsetattr(0, TCSANOW, &newt);
#endif
  while (true) {
#ifndef __WIN32
    char_read = getchar();
#else
    char_read = getch();
#endif
    if (char_read < 0 || char_read == 04)  // EOF or other error
      break;
    reader->buffer[reader->in_index++] = (char)char_read;
    reader->in_index &= (READSIZE-1);
    // Evaluate local guards....
    evaluate_local_guards_of_object(reading_object);
  }
#ifndef __WIN32
  tcsetattr(0, TCSANOW, &oldt);
#endif
  reading_thread_active = false;
  return NULL;
}

// This function is to be called as a local guard
// when checking if there are enough characters read
// to enable this action
bool wait_read(Objectpointer read_object, uint number)
{
  Reading* buffer = (Reading*)object_data(read_object);
  int lkm = buffer->in_index - buffer->out_index;
  if (lkm < 0) {
    lkm += READSIZE;
  }
  return lkm >= number;
}

// This is a procedure to be called to do actual
// reading
int read_chars(Objectpointer read_object, uint number, char localbuffer[])
{
  Reading* buffer = (Reading*)object_data(read_object);
  int lkm = buffer->in_index - buffer->out_index;
  if (lkm < 0) {
    lkm += READSIZE;
  }
  if (lkm > number) {
    lkm = number;
  }
  int i = 0;
  for (; i < lkm; i++) {
    localbuffer[i] = buffer->buffer[buffer->out_index++];
    buffer->out_index &= (READSIZE-1);
  }
  localbuffer[i] = '\0';
  return lkm;
}

#endif

// Initialization routine

static int initialize(uint exe)
{
  int i;
  int function_status = 0;
  int status;
#ifdef READING
  int reading_status;
#endif
  int exe_status[EXECUTORS];
  void **return_status;
 
  if (exe == 0 || exe > EXECUTORS) {
    exe = EXECUTORS;
  }
  executors = exe;

  // Initialize scheduler mutex and semaphore

  if (pthread_mutex_init(&creator_mutex, NULL) != 0) {
    perror("Initalization of creator mutex failed");
  }
  if (pthread_mutex_init(&ready_mutex, NULL) != 0) {
    perror("Initalization of ready queue mutex failed");
  }
  if (pthread_mutex_init(&dup_mutex, NULL) != 0) {
    perror("Initalization of dup queue mutex failed");
  }
  if (pthread_mutex_init(&complete_mutex, NULL) != 0) {
    perror("Initalization of complete queue mutex failed");
  }
  if (sem_init(&ready_semaphore, 0, 0) != 0) {
    perror("Initalization of ready queue semaphore failed");
  }
  if (sem_init(&ready_free_semaphore, 0, executors+1) != 0) {
    perror("Initalization of ready queue semaphore failed");
  }
  if (sem_init(&complete_free_semaphore, 0, COMPLETE_LEN-1) != 0) {
    perror("Initalization of complete queue semaphore failed");
  }
  if (sem_init(&complete_semaphore, 0, 0) != 0) {
    perror("Initalization of complete queue semaphore failed");
  }

  // Create executor threads

  for(i = 0; i < executors; i++) {
    exe_status[i] = pthread_create(&executor_threads[i], NULL, executor, (void*)(long) i);
    if (exe_status[i] != 0) {
      Error(PRINTOUT, "Initialize: Starting of executor failed, status %d, executor %d\n", exe_status[i], i);
      function_status = 2;
    }
  }
#ifdef READING
  if (function_status == 0) {
    reading_status = pthread_create(&reading_thread, NULL, reader_body, NULL);
    if (reading_status != 0) {
      Error(PRINTOUT, "Initialize, Starting of reader failed, status %d\n", reading_status);
      function_status = 2;
    }
  }
#endif
  if (function_status != 0) {
    // Start failed, remove all that did not fail
    for(i = 0; i < executors; i++) {
      if (exe_status[i] == 0) {
	pthread_join(executor_threads[i], return_status);
      }
    }
  }
  return function_status;
}

//
// Closing down everything
//
static int post_mortem()
{
  int function_status = 0;
  void **return_status = calloc(2, sizeof(uint));

  for(uint i = 0; i < executors; i++) {
    int status = pthread_join(executor_threads[i], return_status);
    Debug("Executor %d exit found\n", i+1);
    if (status != 0) {
      Error(PRINTOUT, "Post mortem: Joining of executor failed, status %d, executor %d\n", status, i+1);
      function_status = 1;
    }
  }

  pthread_mutex_destroy(&creator_mutex);
  pthread_mutex_destroy(&ready_mutex);
  pthread_mutex_destroy(&dup_mutex);
  pthread_mutex_destroy(&complete_mutex);
  sem_destroy(&ready_semaphore);
  sem_destroy(&ready_free_semaphore);
  sem_destroy(&complete_semaphore);
  sem_destroy(&complete_free_semaphore);
  return function_status;
}

// This starts everything

int runner(uint threads, application application_init )
{
  int status = 0;
  action_count = 0;
#ifdef LOG_FILE
  log_file = fopen(LOG_FILE, "w");
  LOG3("Runner: %d threads, application address %x\n", threads, application_init);
#endif
#ifdef READING
  // Create reading thread (emulates interrupt)
  reading_thread_active = true;
  reading_object = create_object(&read_contents, NULL, NULL);
  read_contents.in_index = 0;
  read_contents.out_index = 0;
#endif
  if (application_init == NULL) {
    Error(PRINTOUT, "Null application initialization code. Exiting.\n");
#ifdef LOG_FILE
    fclose(log_file);
#endif
    return 2;
  }
  application_init();
  if ((status = initialize(threads)) == 0) {
    LOG1("Runner: Thread initialization successful\n");
    scheduler();
    status = post_mortem();
#ifdef STATISTICS
    printf("Common guard evaluated %ld times, local guard %ld times\n", common_guard_count, local_guard_count);
    LOG3("Runner: Common guard evaluated %ld times, local guard %ld times\n", common_guard_count, local_guard_count);
#endif
    Debug("Program finished %d\n", status);
  } else {
    Error(PRINTOUT, "Initialization failed, status %d\n", status);
  }
#ifdef LOG_FILE
  LOG2("Runner: End status %d\n", status);
  fclose(log_file);
#endif
  return status;
}
