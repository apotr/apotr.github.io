// Anna Sokolinskaya

#ifndef ACTIONPARSER_H_
#define ACTIONPARSER_H_

#include <fstream>
#include <map>
#include <vector>
#include "rapidxml.hpp"
#include "rapidxml_utils.hpp"
#include "actionexception.hpp"

// Number of action participants
#ifndef MAX_PARTICIPANTS
#define MAX_PARTICIPANTS (sizeof(unsigned int)*8-1)
#endif

// info about one object
struct ObjectInfo {
	int rolesNumber; // number actions the object parcicapates in
	std::string init; // initial value
	rapidxml::xml_node<>* classNode;  // poiter to the class of this object	
};

typedef std::map<std::string, ObjectInfo> ObjectMap; // contains all objects in the system
typedef ObjectMap::iterator ItObj;

// info about one class
struct ClassInfo {
	bool copyFunction; // true if copy function is given
	bool deleteFunction; // // true if delete function is given
	bool initFunction; // // true if init function is given
	rapidxml::xml_node<>* classNode; // pointer to the class XML node	
};

typedef std::map<std::string, ClassInfo> ClassMap; // contains all the classes in the system
typedef ClassMap::iterator ItClass;

// info about one action descriptor
struct ActDescInfo {
	bool commonGiven; // true if common guard is given
	unsigned int partCount; // number of parcipating objects
	int index; // index in the list of action descriptors
	std::vector<std::string> paramVector; // list of formal parameters
	rapidxml::xml_node<>* actionNode; // pointer to the action descriptor XML node
};

typedef std::map<std::string, ActDescInfo> ActDescMap;
typedef ActDescMap::iterator ItAct;

// info about one action
struct InstanceInfo {
	std::vector<std::string> objects; // list of actual parpicipants
	std::vector<std::string> parameters; // list of actual parameters
	ActDescInfo *actDescInfo; // pointer to the corresponding action descriptor
};

typedef std::vector<InstanceInfo> InstanceVector;
typedef InstanceVector::iterator ItInsnance;

class ActionParser
{
public:
	ActionParser();
    ~ActionParser();
	void parseFile(const char* inFilename, const char* outFilename); // parse XML file with a program
	
private:
	rapidxml::file<>* inputFile; // input file
    rapidxml::xml_document<>* doc; // XML document containing parsed data
	std::ofstream outputFile; // output file
	ObjectMap objMap; // info about objects
	ActDescMap actMap; // info about action descriptors
	ClassMap classMap; // info about classes
	InstanceVector instanceVector; // info about actions
	int objectCounter; // number of objects
	int threadsNumber; // number of processing threads
	
	// code generating functions
	void parseTypes(rapidxml::xml_node<>* first); // parse element types
	void parseClasses(rapidxml::xml_node<>* first); // parse class descriptors
	void parseActDesc(rapidxml::xml_node<>* first); // parse action descriptors
	void createClasses(); // output creation of class descriptors
	void createActionDes(); // output creation of action descriptors
	void parseInit(rapidxml::xml_node<>* first); // parse initialization element
	void parseObject(rapidxml::xml_node<>* object); // parse an object element
	void parseActionInstances(rapidxml::xml_node<>* header); // parse actions
	void createInstances(); // output creation of objects and actions
	void outputInitFunction(rapidxml::xml_node<>*node, ClassInfo& info); // output initialization function for a class
	void outputCopyFunction(rapidxml::xml_node<>*node, ClassInfo& info); // output copy function for a class
	void outputDeleteFunction(rapidxml::xml_node<>*node, ClassInfo& info); // output delete function for a class
	
	// auxiliary functions
	// split string into multuple strings
	void splitString(const std::string& str, std::vector<std::string>& tokens, const std::string delimiters);
	std::string getText(rapidxml::xml_node<>*node); // get textual content of the node
	std::string trim(const std::string& str); // trim a string from left and right
	std::string numberToString(int num); // convert number to a string
	int stringToNumber(const std::string& str); // convert srting to a number
};

#endif /* ACTIONPARSER_H_ */
